import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class StringFinder {
	
	public static void main(String [] a)
	{
		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
        try {
        	
        	System.out.println("Enter source string - ");
			String  inputStr = br.readLine();
			
			System.out.println("Enter pattern string - ");
			String ptrn=br.readLine();
			
			findAllOccurancesOf(inputStr, ptrn);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Failed to read input string");
			e.printStackTrace();
		}
	}
	/*
	 *  All positions are printed considering input string starting with position 0
	 */
	
	public static void findAllOccurancesOf(String source, String ptrn)
	{
		boolean notfound=true;
		
		char [] sourceString = source.toCharArray();
		char [] pattern = ptrn.toCharArray();
		
		char begin = pattern[0];
		
		int jumpCount = pattern.length;
		
		for(int i =0;i<sourceString.length;)
		{
			//System.out.println("letter index under scan " + i);
			
			if(begin==sourceString[i])
			{	
				if(isCompleteMatchPresent(sourceString, pattern, i))
				{
					i=i+jumpCount;
					notfound=true;
				}
				else
					i++;
			}
			else
				i++;
		
			if(notfound)
				System.out.println("Pattern Not Found in String");
		}
	}
	
	public static boolean isCompleteMatchPresent(char [] src, char [] p, int i)
	{
		
		//System.out.println("found first letter match at .. progressing ... " + i);
		
		if(p.length> src.length-i)
			return false;
		
		int x=0,v=0;
		for(x = i; x < i+p.length;x++,v++)
		{
			if(src[x]!=p[v])
				return false;
		}
		
		System.out.println("Match Found at " + i);
		return true;
		
	}
	
}
